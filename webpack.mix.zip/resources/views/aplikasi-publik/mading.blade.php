@extends('layouts.app')

@section('title')
Mading Online Fasilkom | Kabinet Arthasastra
@endsection

@section('content')
<section id="mading" class="mading" style="margin-top: 100px">
    <div class="row mt-4 text-center">
        <div class="col-md-12 d-flex justify-content-center">
            <img src="{{ url('frontend/assets/img/mading.svg') }}" style="width: 45%;">
        </div>
        <h5 class="fw-light mt-5">" Jangan diliat dulu ya aku lagi hias hias madingnya nih pokoknya spesial <br> ga boleh liat ayo tutup mata putar balik! "</h5>
    </div>
</section>
@endsection