@extends('layouts.app')

@section('title')
LPJ Online | Kabinet Catralingga
@endsection

@section('content')
<section id="lpj" class="lpj" style="margin-top: 100px">
    <div class="row mt-4 text-center">
        <div class="col-md-12 d-flex justify-content-center">
            <img src="{{ url('frontend/assets/img/lpj.svg') }}" style="width: 40%;">
        </div>
        <h5 class="fw-light mt-5">" Hmm.. yang mana ya laporannya aku lupa simpen nih,<br> boleh bantuin aku cari laporannya gak? "</h5>
    </div>
</section>
@endsection