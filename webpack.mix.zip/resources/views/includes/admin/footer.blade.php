<footer class="main-footer">
  <div class="footer-left">
    Copyright &copy; 2022 <div class="bullet"></div> Departemen Pengembangan Teknologi Informasi BEM Fasilkom Unsika 2022</a>
  </div>
</footer>