<!-- ======= Footer ======= -->
<footer id="footer" class="footer">

	<div class="container">
		<div class="copyright text-start">
			<div class="row text-center mt-3">
				<div class="col-md mt-3">
          <p>Copyright &#169; 2022 Departemen Pengembangan Teknologi Informasi <br> BEM Fasilkom Unsika 2022</p>
				</div>
			</div>
		</div>
	</div>

</footer>
<!-- End Footer -->