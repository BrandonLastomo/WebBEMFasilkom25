<!-- Vendor JS Files -->
<script src="{{ url('pkkmb/assets/vendor/bootstrap/js/bootstrap.bundle.js') }}"></script>
<script src="{{ url('pkkmb/assets/vendor/aos/aos.js') }}"></script>
<script src="{{ url('pkkmb/assets/vendor/horizontal-timeline/js/horizontal_timeline.2.0_v2.0.5.3.min.js') }}"></script>
<script src="{{ url('pkkmb/assets/vendor/owl-carousel/js/owl.carousel.min.js') }}"></script>

<!-- Template Main JS File -->
<script src="https://cdn.jsdelivr.net/gh/LikaloLLC/tourguide.js@0.2.0/tourguide.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>

<!-- Main JS File -->
<script src="{{ url('pkkmb/assets/js/main.js') }}"></script>
<script src="{{ url('pkkmb/assets/js/custom.js') }}"></script>