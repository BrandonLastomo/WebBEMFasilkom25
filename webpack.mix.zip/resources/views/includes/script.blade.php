<!-- Vendor JS Files -->
<script src="{{ url('frontend/assets/vendor/bootstrap/js/bootstrap.bundle.js') }}"></script>
<script src="{{ url('frontend/assets/vendor/aos/aos.js') }}"></script>
<script src="{{ url('frontend/assets/vendor/php-email-form/validate.js') }}"></script>
<script src="{{ url('frontend/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
<script src="{{ url('frontend/assets/vendor/purecounter/purecounter.js') }}"></script>
<script src="{{ url('frontend/assets/vendor/isotope-layout/isotope.pkgd.min.js') }}"></script>
<script src="{{ url('frontend/assets/vendor/glightbox/js/glightbox.min.js') }}"></script>
<script src="{{ url('frontend/assets/vendor/owl-carousel/js/owl.carousel.min.js') }}"></script>
<script src="{{ url('frontend/assets/vendor/selectric/public/jquery.selectric.min.js') }}"></script>

<!-- Template Main JS File -->
<script src="https://cdn.jsdelivr.net/gh/LikaloLLC/tourguide.js@0.2.0/tourguide.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
{{-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script> --}}
<script src="{{ url('frontend/assets/js/main.js') }}"></script>